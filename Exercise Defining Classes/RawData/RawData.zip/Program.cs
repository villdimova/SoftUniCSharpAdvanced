﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Linq;

namespace RawData
{
    public class Program
    {
        static void Main(string[] args)
        {
            int countCars = int.Parse(Console.ReadLine());
            List<Car> cars = new List<Car>();

            for (int i = 0; i < countCars; i++)
            {
                var carInfo = Console.ReadLine().Split().ToArray();
                

                string model = carInfo[0];
                int engineSpeed = int.Parse(carInfo[1]);
                int enginePower = int.Parse(carInfo[2]);
                Engine engine = new Engine(engineSpeed, enginePower);
                int cargoWeight = int.Parse(carInfo[3]);
                string cargoType = carInfo[4];
                Cargo cargo = new Cargo(cargoWeight, cargoType);


                Tire[] tires = new Tire[4];
               
                int counter = 0;
                for (int j = 0; j < 7; j+=2)
                {
                    
                    Tire tire = new Tire(double.Parse(carInfo[j + 5]), int.Parse(carInfo[j + 6]));
                    tires[counter] = tire;
                    counter++;
                }

                Car car = new Car(model, engine, cargo, tires);
                cars.Add(car);
            }

            string filterCriteria = Console.ReadLine();

            List<Car> selectedCars = new List<Car>();

            if (filterCriteria== "fragile")
            {
                

                foreach (var car in cars.Where(c => c.Cargo.CargoType == "fragile"))
                {
                    foreach (var tire in car.Tires)
                    {
                        if (tire.TirePressure<1)
                        {
                            selectedCars.Add(car);
                            break;
                        }
                    }
                }
            }

            else if (filterCriteria== "flamable")
            {
                foreach (var car in cars.Where(c => c.Cargo.CargoType == "flamable"))
                {
                    if (car.Engine.EnginePower>250)
                    {
                        selectedCars.Add(car);
                    }
                }
            }


            foreach (var car in selectedCars)
            {
                Console.WriteLine(car.Model);
            }

        }
    }
}
