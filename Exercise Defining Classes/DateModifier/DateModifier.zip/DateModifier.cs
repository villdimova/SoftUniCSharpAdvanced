﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DateModifier
{
    public class DateModifier
    {
        


        public double GetDiffrenceInDaysBetweenTwoDates(string firstDate, string secondDate)
        {
            DateTime startDate = DateTime.Parse(firstDate);
            DateTime endDate = DateTime.Parse(secondDate);

            double differenceBetweenTwoDates = (endDate - startDate).TotalDays;

            return differenceBetweenTwoDates;

        }
    }
}
